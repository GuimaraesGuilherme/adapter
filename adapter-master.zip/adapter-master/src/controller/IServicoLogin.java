package controller;

import model.Autenticacao;
import model.Login;

public interface IServicoLogin {

    void logar(Autenticacao autenticacao);
}
