package controller;

import model.Login;

public class LoginDuasEtapas {

    public void confirmarSegundaEtapa(int chave) {
        System.out.println("Login chave");
    }

    public void fazerLogin(Login login) {
    }
}
