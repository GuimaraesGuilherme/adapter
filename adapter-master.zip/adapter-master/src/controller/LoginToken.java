package controller;

public class LoginToken {
    public void enviarToken(int token) {
        System.out.println("Login token");
    }
}
